package org.upgrad.upstac.testrequests.lab.models;

public enum TestStatus {
    NEGATIVE,POSITIVE
}
